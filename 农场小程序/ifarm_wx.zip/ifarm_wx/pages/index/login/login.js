// pages/index/login/login.js
let Data = require('../../../api/data.js');
let Api = require('../../../api/api.js')
let Dialog = require('../../../utils/dialog.js')
let action;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:undefined,
    isCanWxUseInfo: false,
  },

  userInfoHandler:function(e){
    if (e.detail.userInfo == undefined) {
      Dialog.showTips("继续使用需要您的授权");
      return;
    }
    login(this);
  },

  loginClick:function(e){
    login(this);
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    action = options.action;
    let that =this;
    Api.getBanner({ 'page': 0, 'size': 5 }, {
      success: function (e) {
        that.setData({
          imgUrl: e.data.content[0].coverUrl,
        });
      }
      // wx.hideToast();
    });
    wx.getSetting({
        success:res=>{

          if (res.authSetting['scope.userInfo'] ==true){

          }else{
            that.setData({
              isCanWxUseInfo: false,
            })
          }
        },
        fail:res=>{
          wx.showToast({
            title: "fail",
          })
        }
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

function login(that) {

  wx.login({
    success: function (result) {
      wx.getUserInfo({
        success: function (res) {

          let code = result.code;
          res.code = code;
          Api.login(res, {
            success: function (apiReslut) {
              Data.saveToken(apiReslut.data.token);
              Data.saveUser(apiReslut.data.userBean)
              wx.showToast({
                title: '已登录',
              })
              if (action==1){
                wx.redirectTo({
                  url: '../../me/mycenter/index',
                  success: function(res) {},
                  fail: function(res) {},
                  complete: function(res) {},
                })
              }else{
                wx.redirectTo({
                  url: '../chosenvegatable/index',
                  success: function (res) { },
                  fail: function (res) { },
                  complete: function (res) { },
                })
              }
            },
            fail: function (apiReslut) {

            }
          })
        },
        fail: function (res) {
          this.setData({
            isCanWxUseInfo: false,
            showDialog: true,
          })
        }
      })


    }
  });
}
