// pages/me/mycenter/index.js

let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let Dialog = require('../../../utils/dialog.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:undefined,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     this.setData({
       userInfo:Data.getUser(),
     })

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  tapTel(){
    wx.makePhoneCall({
      phoneNumber: '400-632-3336'
    })
  },
  tapAddress(){
    wx.navigateTo({
      url: `../addresslist/index`
    });
  },
  tapRecord(){
    wx.navigateTo({
      url: `../myrecord/index`
    });
  },
  tapMyinfo(){
    wx.navigateTo({
      url: `../myinfo/index`
    });
  },
  tapCoupon(){
    wx.navigateTo({
      url: `../mycoupon/index`
    });
  },
  tapCardlist(){
    wx.navigateTo({
      url: `../cardlist/index`
    });
  },
  tapMember(){
    wx.navigateTo({
      url: `../mymember/index`
    });
  }
})
