let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
Page({
  data: {
    problemListData:[]
  },
  onLoad: function () {
    let that=this;
    Api.question({},{
      success: data=>{
        //console.dir(data);
        let result = data.data.content
        let problemList=[];
        let tempCategory;
        result.map(item => {
          if (tempCategory == undefined || tempCategory != item.category.name) {
            tempCategory = item.category.name;
            problemList.push({ name: tempCategory, child: [item] });

          } else {
            problemList[problemList.length - 1].child.push(item);
          }

          item.status = false

        });
        //console.dir(problemList);
        that.setData({
          problemListData: problemList
        })
      }
    
      
    });
  },
  toggleDetail(e){
    let [index,flag]=[e.currentTarget.dataset.index,e.currentTarget.dataset.flag];
    this.data.problemListData[index].child.map((item,index)=>{
      if(index==flag){
          item.status=!item.status
          this.setData({
            problemListData:this.data.problemListData
          })
          //console.log(this.data.problemListData);
          return ;
      }
    })
  }
})
