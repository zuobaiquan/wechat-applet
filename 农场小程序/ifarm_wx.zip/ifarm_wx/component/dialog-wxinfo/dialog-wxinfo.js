// component/dialog-wxinfo/dialog-wxinof.js
let Data = require('../../api/data.js');
let Api = require('../../api/api.js')
let Dialog = require('../../utils/dialog.js')
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    canGetUserInfo: {
      type: Boolean,
    },
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    close: function (e) {
     
      this.triggerEvent('close', {}, {});
    },
    bindGetUserInfo: function (e) {
   
      if (e.detail.userInfo==undefined){
        Dialog.showTips("继续使用需要您的授权");
        return;
      }
      Data.saveWxUser(e.detail);
      this.triggerEvent('wxLogin', { wxinfo: e.detail }, {});
      // wx.login({
      //   success: res => {
      //     console.dir(res);
      //     let code = res.code;
      //     e.detail.code = code;
      //     Api.login(e.detail, {
      //       success: result => {
      //         Data.saveToken(result.data.token);
      //         Data.saveUser(result.data.userBean)
            
      //       },
      //       fail: result => {
      //         console.dir(result);
      //       }
      //     })
      //   }
      // })

    },
  }
})
