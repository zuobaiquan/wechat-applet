let user ;
let wxUser ;
let openId ;
let token ;

function isLogin() {
  if (getUser() != undefined && getUser().id!=undefined) {
    return true;
  } else {
    return false; 
  }
}

function saveUser(userInfo) {
  wx.setStorageSync('user', userInfo);
}

function getUser() {
    user = wx.getStorageSync('user');
  return user;
}

function saveWxUser(wxUser) {
  wx.setStorageSync('wxUser', wxUser);
}

function getOpenId() {

    openId = wx.getStorageSync('openId');
  return openId;
}
function saveOpenId(openId) {
  wx.setStorageSync('openId', openId);
}

function getWxUser() {
  if (!wxUser || wxUser == undefined) {
    wxUser = wx.getStorageSync('wxUser');
  }
  return wxUser;
}

function saveToken(info) {
  token = info;
  wx.setStorage({
    key: 'token',
    data: token,
  })
}

function getToken() {
  if (token == undefined) {
    token = wx.getStorageSync("token");
  }
  return token;
}


function logout() {
  // saveToken(null);
  user = undefined;
  token = undefined;
  wxUser = undefined;
  openId = undefined,
    wx.clearStorageSync('user');
  wx.clearStorageSync('wxUser');
  wx.clearStorageSync('openId');
}

//由于真机上时间处理有问题， 所以这边都是先处理成兼容的格式再解析
function getDateFromGMT( timeString){
  let time = timeString.replace('T', ' ');
  time = time.substring(0, 19);
  time = time.replace(/-/g, '/')
  return new Date(time);
}

module.exports = {
  getUser: getUser,
  saveUser: saveUser,
  isLogin: isLogin,
  saveWxUser: saveWxUser,
  getWxUser: getWxUser,
  saveOpenId: saveOpenId,
  getOpenId: getOpenId,
  logout: logout,
  getToken: getToken,
  saveToken: saveToken,
  getDateFromGMT: getDateFromGMT,
}