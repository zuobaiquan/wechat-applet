Page({
  data: {
    activeIndex:1,
    tabList:['未使用','已使用','已过期'],
    list:[]
  },
  onLoad: function (options) {

  },
  onShow: function () {

  },
  changeTab(e){
    this.setData({
      activeIndex:++e.currentTarget.dataset.index
    })
  }
})
