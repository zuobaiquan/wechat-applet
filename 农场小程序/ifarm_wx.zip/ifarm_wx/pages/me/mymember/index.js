// pages/me/myrecord/index.js

let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let Dialog = require('../../../utils/dialog.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    noMember:false,
    list:[],
  },
  onLoad: function (options) {

  },
  onShow: function () {

  },
  onReachBottom: function () {

  },
  tapDelete(e){
    wx.showModal({
      content: '是否移除家庭成员？',
      cancelColor:'#999999',
      confirmColor:'#333333',
      success: function(res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
})
