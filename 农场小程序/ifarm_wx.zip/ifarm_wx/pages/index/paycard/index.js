Page({
  data: {
    //vegatable or chicken
    type:'chicken',
    cardInfo:{
      title:'菜地卡'
    }
  },
  onLoad: function (options) {
    if(this.data.type=='chicken'){
      wx.setNavigationBarTitle({
        title:'选鸡卡'
      })
      this.data.cardInfo.title='养鸡卡'
      this.setData({
        cardInfo:this.data.cardInfo
      })
    }
  },
  onReady: function () {

  },
  onShow: function () {

  }
})
