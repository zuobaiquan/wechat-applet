
let name;
let password;

let Api = require('../../../api/api.js')
let Dialog = require('../../../utils/dialog.js')
Page({
  data: {
    showTips: false
  },
  verifyCard: function (e) {
    name = e.detail.value;
  },
  verifyPass: function (e) {
    password = e.detail.value;
  },
  saveResult: function (e) {
    if (name == undefined || name.length == 0) {
      Dialog.showTips("卡号不能为空");
      return;
    }
    if (password == undefined) {
      Dialog.showTips("密码不能为空");
      return;
    }
  },
  onLoad: function (options) {

  }
})
