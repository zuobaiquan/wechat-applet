Page({
  data: {
    activeIndex:1,
    tabList:['可用','已失效'],
    list:[]
  },
  onLoad: function (options) {

  },
  onShow: function () {

  },
  changeTab(e){
    this.setData({
      activeIndex:++e.currentTarget.dataset.index
    })
  }
})
