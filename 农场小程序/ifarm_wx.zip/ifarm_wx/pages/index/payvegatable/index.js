let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let Dialog = require('../../../utils/dialog.js')
let phone;
let code;
Page({
  data: {
    yearList: ['1年', '2年', '3年'],
    index: 0,
    money:0,
    areaList: [],
    itemList: [],
    orderBean: undefined,
    m: 0,
    s: 0,
    showDialog:true,
    phone:'',
  },

  //获取手机号码
  getPhone:function(e){
    //console.dir(e)
    let data = e.detail.data;
    data.code = code;
    //提交数据后台解码
    Api.getWxPhone(data, {
      success: result => {
        //console.dir(result);
        phone = result.data.purePhoneNumber;
        this.setData({
          phone: phone,
          showDialog: false,
        })
        let user = Data.getUser();
        if (user.phone == undefined || user.phone == null) {
          user.phone = phone;
        }
        Api.editUser(user, {
          success: editResult => {
            Data.saveUser(editResult.data);
          }
        })
      }
    })
  },

  onPay: function (e) {
    if (phone == undefined || phone.length != 11) {
      Dialog.showTips("请输入正确的手机号码");
      return;
    }
    let year = (parseInt(this.data.index) + parseInt(1));
    let params = {
      orderSn: this.data.orderBean.orderSn,
      payTimes: year,
      phone: phone,
    };
    Api.payOrder(params, {
      success: res => {
        let info = res.data;
        wx.requestPayment({
          timeStamp: info.timeStamp,
          nonceStr: info.nonceStr,
          package: info.package,
          signType: info.signType,
          paySign: info.paySign,
          success: payResult => {
            clearTimeout(countTimeId);
            wx.redirectTo({
              url: '../../me/paysuccess/index?orderSn=' + this.data.orderBean.orderSn,
              success: function (res) { },
              fail: function (res) { },
              complete: function (res) { },
            })
          },
        })
      }
    })
  },

  phoneInput: function (e) {
    //console.dir(e);
    phone = e.detail.value;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    let startTimestamp = Data.getDateFromGMT(getApp().globalData.orderBean.createTime).getTime();


    let endTimestamp = startTimestamp + 3 * 60 * 1000;
    countTime(this, endTimestamp);

    let list = getApp().globalData.orderGardenItems;
    let areaList = {};
    let itemList = {};
    for (let i = 0; i < list.length; i++) {
      let item = list[i];
      let areaId = item.gardenArea.id;
      if (areaList[areaId] == undefined) {
        areaList[areaId] = item.gardenArea;
      }
      if (itemList[areaId] == undefined) {
        itemList[areaId] = [];
      }
      itemList[areaId].push(item);
    }

    let user = Data.getUser();
    let showDialog =false;

    if (user.phone == undefined || user.phone==null){
      showDialog = true;

      wx.login({
        success: res => {
          //获取 code 给后台解析手机号数据
          code = res.code;
        }
      });
    }
    phone = user.phone;
    //console.log(user)
    this.setData({
      areaList: areaList,
      itemList: itemList,
      money: getApp().globalData.orderBean.money,
      orderBean: getApp().globalData.orderBean,
      showDialog: showDialog,
      phone: phone,
    })


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  onUnload: function () {
    clearTimeout(countTimeId);
  },

  yearChosen(e) {
    //console.dir(e);
    this.setData({
      index: e.detail.value,
      money: ((parseInt(e.detail.value) + parseInt(1)) * parseFloat(this.data.orderBean.money)).toFixed(2),
    })
    //console.log(this.data.money);
  }

})

function countTime(that, endTimestamp) {
  var date = new Date();
  var now = date.getTime();
  //设置截止时间
  var end = endTimestamp;
  var leftTime = end - now; //时间差
  var d, h, m, s, ms;
  if (leftTime >= 0) {
    d = Math.floor(leftTime / 1000 / 60 / 60 / 24);
    h = Math.floor(leftTime / 1000 / 60 / 60 % 24);
    m = Math.floor(leftTime / 1000 / 60 % 60);
    s = Math.floor(leftTime / 1000 % 60);
    ms = Math.floor(leftTime % 1000);
    if (ms < 100) {
      ms = "0" + ms;
    }
    if (s < 10) {
      s = "0" + s;
    }
    if (m < 10) {
      m = "0" + m;
    }
    if (h < 10) {
      h = "0" + h;
    }
  } else {
    clearTimeout(countTimeId);
    Dialog.showTips("锁定时间已结束", () => {
      wx.reLaunch({
        url: '../index/index',
      })
    })
    return;
  }
  //将倒计时赋值到div中

  //递归每秒调用countTime方法，显示动态时间效果
  that.setData({
    m: m,
    s: s,
  })
  countTimeId = setTimeout(
    function () {
      countTime(that, endTimestamp);
    }
    , 1000);
}

let countTimeId;
