
let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let Dialog = require('../../../utils/dialog.js')
let id;
let isRefreshOnShow = true;
let isLoadList =false;
let page =0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    height:wx.getSystemInfoSync().screenHeight,
  },


  photoClick: function (e) {
    let photos = e.currentTarget.dataset.items;
    let cureentItem = e.currentTarget.dataset.item;
    let urls = [];
    for (let i of photos) {
      urls.push(i.url);
    }
    isRefreshOnShow = false;
    wx.previewImage({
      urls: urls,
      current: cureentItem.url
    })
  },

  bindscrolltolower:function(e){
    //console.dir(e);
    if (isLoadList==false){
      loadList(this)
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //console.log(options);
    page = 0;
    id = options.id;
    loadList(this);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (isRefreshOnShow) {
      Api.getBill({
        id: id,
      }, {
          success: res => {
            let billBean = res.data.content[0];
            let endTimeName = Data.getDateFromGMT(billBean.endTime).Format("yyyy-MM-dd");
            let startTimeName = Data.getDateFromGMT(billBean.startTime).Format("yyyy-MM-dd");
            billBean.dateName = startTimeName + "-" + endTimeName;
            this.setData({
              billBean: billBean,
            })
          }
        })
    } else {
      isRefreshOnShow = true;
    }

  },
  tapTime() {
    wx.showModal({
      title: "提示",
      content: '有效期：' + this.data.billBean.dateName,
      cancelColor: '#999999',
      confirmColor: '#96cb2c',
      cancelText: '暂不需要',
      confirmText: '续费',
      success: res => {
        if (res.confirm) {
          //console.log('用户点击确定')
          Api.lockGardenItem({ 'gardenId': [this.data.billBean.gardenItem.id] }, {
            success: res => {
              getApp().globalData.orderGardenItems = [this.data.billBean.gardenItem];
              getApp().globalData.orderBean = res.data;
              wx.navigateTo({
                url: '../payvegatable/index',
                success: function (res) { },
                fail: function (res) { },
                complete: function (res) { },
              })
            }
          });
        } else if (res.cancel) {
          //console.log('用户点击取消')
        }
      }
    })
  }
})


Date.prototype.Format = function (fmt) { //author: meizz
  var o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
}


function loadList(that){
  isLoadList = true;
  let param = {
    billId: id,
    'sort': 'id,desc',
    'page': page,
    'size': 20,
  };
  if(page>0){
    param.isShowLoading = false;
  }
  Api.getReport(param, {

      success: res => {
        let list = res.data.content;
        if(list.length>0){
          page = page+1;
        }
        for (let i = 0; i < list.length; i++) {
          let item = list[i];

          let dateName = Data.getDateFromGMT(item.createTime).Format("yyyy-MM-dd hh:mm");
          item.dateName = dateName;
          that.data.list.push(item);
        }

        that.setData({
          list: that.data.list,
        })

      },
      complete:res=>{
        isLoadList = false;
      }
    })
}
