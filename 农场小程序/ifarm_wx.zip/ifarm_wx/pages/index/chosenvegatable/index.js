// pages/index/choose/index.js
let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let Dialog = require('../../../utils/dialog.js')

let refreshOnShow = true;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bigGarden: undefined,
    areaList: [],
    itemList: [],
    selectId: undefined,
    money: 0,

  },

  bannerClick:function(e){
    refreshOnShow  =false;
    wx.previewImage({
      urls: [this.data.bigGarden.coverUrl],
    })
  },

  goToPay: function (e) {
    if (selectItems == undefined || selectItems.length == 0) {
      Dialog.showTips("请先选择菜地");
      return;
    }
    let selectGardenItemIds = [];
    for (var i of selectItems) {
      selectGardenItemIds.push(i.id);
    }
    Api.lockGardenItem({ 'gardenId': selectGardenItemIds }, {
      success: res => {
        getApp().globalData.orderGardenItems = selectItems;
        getApp().globalData.orderBean = res.data;
        wx.navigateTo({
          url: '../payvegatable/index',
          success: function (res) { },
          fail: function (res) { },
          complete: function (res) { },
        })
      }
    });

  },

  onAreaClick: function (e) {
    let areaId = e.target.dataset.item.id;
    this.setData({
      selectId: areaId,
    })
  },

  onItemClick: function (e) {
    let item = e.currentTarget.dataset.item;
    if (item.status == 1) {
      item.check = !item.check;
      this.data.itemList[item.gardenArea.id][item.id].check = item.check;
      this.setData({
        itemList: this.data.itemList,
      })
      refreshMoney(this);
    }
  },
  onLoad: function (options) {
    Api.getIfarm({ id: 1 }, {
      success: res => {
        this.setData({
          bigGarden: res.data.content[0],
        })
      }
    })

  },

  onShow: function () {
    if (refreshOnShow){
      refreshGardenItems(this);
    }else{

      refreshOnShow= true;
    }
  }
})

function refreshMoney(that) {
  selectItems = [];
  let itemGroupList = that.data.itemList;
  let money = 0;
  for (let i in itemGroupList) {
    let itemList = itemGroupList[i];
    for (let j in itemList) {
      if (itemList[j].check) {
        selectItems.push(itemList[j]);
        money = parseFloat(money) + parseFloat( itemList[j].gardenArea.garden.price);
      }
    }
  }
  that.setData({
    money: money.toFixed(2),
  })
}

//已选择的小菜地记录
let selectItems;

//刷新所有小菜地
function refreshGardenItems(that){
  let params = {
    'gardenArea.garden.id': 1,
     "sort": "gardenArea.id",
     isShowLoading:false,
     'size':10000,
  }
  Api.getIfarmItem(params, {
      success: res => {
        let areaList = {};
        let itemList = {};
        for (let i = 0; i < res.data.content.length; i++) {
          let item = res.data.content[i];
          let areaId = item.gardenArea.id;
          if (areaList[areaId] == undefined) {
            areaList[areaId] = item.gardenArea;
          }
          if (itemList[areaId] == undefined) {
            itemList[areaId] = {};
          }
          if (item.status == 0) {
            item.classStyle = 'list4'
          } else if (item.status == 1) {
            item.classStyle = 'list23'
          } else if (item.status == 2) {
            item.classStyle = 'list56'
          } else if (item.status == 3) {
            item.classStyle = 'list4'
          }
          item.check = false;
          itemList[areaId][item.id] = item;
        }

        that.setData({
          itemList: itemList,
          areaList: areaList,
          selectId: res.data.content[0].gardenArea.id,
        })

      }
    })
}
