let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let Dialog = require('../../../utils/dialog.js')

Page({
  data: {
    noAddress:false,
    list:[],
  },

  addAddress:function(e){
    
    wx.navigateTo({
      url: '../newaddress/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  setDefault:function(e){
    //console.dir(e);
    let item = e.currentTarget.dataset.item;
    item.isDefault= true;
    Api.editAddress(item,{
      success:res=>{
        refreshList(this);
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    refreshList(this);
  },
  tapDelete(e){
    let item = e.currentTarget.dataset.item;
    let that = this;
    wx.showModal({
      content: '確认要删除该地址？',
      cancelColor:'#999999',
      confirmColor:'#333333',
      success: function(res) {
        if (res.confirm) {
          //console.log('用户点击确定')
        
          Api.deleteAddress(item.id, {
            success: res => {
              refreshList(that);
            }
          });
        } else if (res.cancel) {
          //console.log('用户点击取消')
        }
      }
    })
  },
  newAddress(){
    // wx.navigateTo({
    //   url: `../newaddress/index`
    // });
  
  }
})

function refreshList(that){
  Api.getAddress({
    userId: Data.getUser().id,
  }, {
      success: res => {
        that.setData({
          list: res.data.content,
        })
      }
    })
}
