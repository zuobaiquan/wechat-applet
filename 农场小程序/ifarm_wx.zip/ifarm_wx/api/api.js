let Method = require('method.js');
let Data = require('data.js');

//登录
function login(info, call) {
  var data = {
    url: 'login',
    param: info,
    callBack: call,
  }
  Method.Post(data);
}

//获取农场
function getIfarm(param, call) {
  var data = {
    url: 'garden',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}

//获取小菜地
function getIfarmItem(param, call) {
  var data = {
    url: 'garden/item',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}
//获取菜地区域
function getIfarmArea(param, call) {
  var data = {
    url: 'garden/area',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}

//锁定菜地
function lockGardenItem(param, call) {
  var data = {
    url: 'order/lock',
    param: param,
    callBack: call,
  }
  Method.Post(data);
}

//支付菜地
function payOrder(param, call) {
  var data = {
    url: 'order/pay',
    param: param,
    callBack: call,
  }
  Method.Post(data);
}

//获取地址
function getAddress(param, call) {
  var data = {
    url: 'address',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}

//获取地址
function addAddress(param, call) {
  var data = {
    url: 'address',
    param: param,
    callBack: call,
  }
  Method.Post(data);
}

//编辑地址
function editAddress(param, call) {
  var data = {
    url: 'address',
    param: param,
    callBack: call,
  }
  Method.Put(data);
}
//编辑地址
function deleteAddress(id, call) {
  var data = {
    url: 'address/' + id,
    param: {},
    callBack: call,
  }
  Method.Delete(data);
}

function getOrder(param, call) {
  var data = {
    url: 'order',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}
//获取已售菜地记录
function getBill(param, call) {
  var data = {
    url: 'bill',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}
//获取管家汇报
function getReport(param, call) {
  var data = {
    url: 'report',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}

//获取文章
function getArticle(param, call) {
  var data = {
    url: 'article',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}

function getWxPhone(param, call) {
  var data = {
    url: 'wx/phone',
    param: param,
    callBack: call,
  }
  Method.Post(data);
}

function editUser(param, call) {
  var data = {
    url: 'user/edit',
    param: param,
    callBack: call,
  }
  Method.Post(data);
}  
function question(param, call) {
  var data = {
    url: 'question',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}  

function getBanner(param, call) {
  var data = {
    url: 'banner',
    param: param,
    callBack: call,
  }
  Method.Get(data);
}  


module.exports = {
  login: login,
  getReport: getReport,
  getBill: getBill,
  getIfarm: getIfarm,
  getIfarmItem: getIfarmItem,
  getIfarmArea: getIfarmArea,
  lockGardenItem: lockGardenItem,
  payOrder: payOrder,
  getAddress: getAddress,
  addAddress: addAddress,
  editAddress: editAddress,
  deleteAddress: deleteAddress,
  getOrder: getOrder,
  getArticle: getArticle,
  getWxPhone: getWxPhone,
  editUser: editUser,
  question: question,
  getBanner: getBanner,
}