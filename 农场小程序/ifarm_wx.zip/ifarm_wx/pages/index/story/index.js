// pages/index/story/index.js
let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    article:undefined
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // Api.getArticle({
    //   id: options.id,
    // },{
    //   success:res=>{
    //     let article = res.data.content[0];
    //     this.setData({
    //       article: article,
    //     })
    //     wx.setNavigationBarTitle({
    //       title: article.title,
    //     })
    //   }
    // });
    this.setData({
      url: 'https://ifarm.iqiys.cn/article/' + options.id,
    })
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  }

})
