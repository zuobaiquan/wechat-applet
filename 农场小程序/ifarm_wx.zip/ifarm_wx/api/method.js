var Config = require('config.js');
var Data = require('data.js');


function post(data) {
  let url = data.url;
  let param = data.param;
  let callBack = data.callBack;

  if (param.isShowLoading == undefined || param.isShowLoading == true) {
    wx.showLoading({
      title: "正在请求",
      mask: true,
    })
  }

  wx.request({
    url: Config.getBaseUrl() + url,
    data:param,
    method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    header: {
      'content-type': 'application/json',
      'token':Data.getToken(),
    },
    complete: function (res) {
      onComplete(res, callBack)
    },
    fail: function (res) {
      onFail(param, res, callBack)
    },
    success: function (res) {
      onSuccess(param, res, callBack);
    }
  })

}

function get(data) {
  let url = data.url;
  let param = data.param;
  let callBack = data.callBack;

  if (param.isShowLoading == undefined || param.isShowLoading == true) {
    wx.showLoading({
      title: "正在请求",
      mask: true,
    })
  }

  wx.request({
    url: Config.getBaseUrl() + url,
    data: param,
    method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    header: {
      'token': Data.getToken(),
    },
    complete: function (res) {
      onComplete(res, callBack)
    },
    fail: function (res) {
      onFail(param, res, callBack)
    },
    success: function (res) {
      onSuccess(param, res, callBack);
    }
  })
}


function put(data) {
  let url = data.url;
  let param = data.param;
  let callBack = data.callBack;

  if (param.isShowLoading == undefined || param.isShowLoading == true) {
    wx.showLoading({
      title: "正在请求",
      mask: true,
    })
  }

  wx.request({
    url: Config.getBaseUrl() + url,
    data: param,
    method: 'PUT', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    header: {
      'token': Data.getToken(),
    },
    complete: function (res) {
      onComplete(res, callBack)
    },
    fail: function (res) {
      onFail(param, res, callBack)
    },
    success: function (res) {
      onSuccess(param, res, callBack);
    }
  })
}

function Delete(data) {
  let url = data.url;
  let param = data.param;
  let callBack = data.callBack;

  if (param.isShowLoading == undefined || param.isShowLoading == true) {
    wx.showLoading({
      title: "正在请求",
      mask: true,
    })
  }

  wx.request({
    url: Config.getBaseUrl() + url,
    data: param,
    method: 'DELETE', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    header: {
      'token': Data.getToken(),
    },
    complete: function (res) {
      onComplete(res, callBack)
    },
    fail: function (res) {
      onFail(param, res, callBack)
    },
    success: function (res) {
      onSuccess(param, res, callBack);
    }
  })
}

function onComplete(res, callBack) {
 // console.dir(res);
  if (isFunction(callBack.complete)) {
    callBack.complete(res);
  }
}


function onFail(params, res, callBack) {
  wx.hideLoading();
  //console.dir(params);
  if (params.isShowDialog == undefined || params.isShowDialog) {
    wx.showModal({
      title: '出错了…',
      showCancel: false,
      confirmText: '确定',
    })
  }
  if (isFunction(callBack.fail)) {
    callBack.fail(res);
  }
}


function onSuccess(params, res, callBack) {
  wx.hideLoading();

  if (res.statusCode==200){
    if (isFunction(callBack.success)) {
      callBack.success(res);
    }
  }else{
    if (res.data.code == -100) {
      Data.logout();
      wx.reLaunch({
        url: '../index/index?relogin=1',
      })
      return;
    }
    if (res.data.message != undefined && res.data.message.length > 0) {
      wx.showModal({
        title: '提示',
        content: res.data.message,
        showCancel: false,
        confirmText: '确定',
      })
      if (isFunction(callBack.fail)) {
        callBack.fail(res);
      }
    }
  }
 

}


function upload(data) {
  let url = data.url;
  let param = data.param;
  let callBack = data.callBack;


  param.timestamp = Math.floor(Date.now() / 1000);

  if (param.isShowLoading == undefined || param.isShowLoading == true) {
    wx.showLoading({
      title: "正在请求",
      mask: true,
    })
  }

  wx.uploadFile({
    url: Config.getBaseUrl() + url,
    header: {
      'token': Data.getToken(),
    },
    filePath: data.filePath,
    name: data.fileName,
    formData: param,
    complete: function (res) {
    
      if (isFunction(callBack.complete)) {
        callBack.complete(res);
      }
    },
    fail: function (res) {
      wx.hideLoading();
      wx.showModal({
        title: '请求错误',
        showCancel: false,
        confirmText: '确定',
      })
      if (isFunction(callBack.fail)) {
        callBack.fail(res);
      }
    },
    success: function (res) {
      wx.hideLoading();
      res.data = JSON.parse(res.data);
      //console.dir(res);
      if (res.data.code == -100) {
        Data.logout();
        wx.reLaunch({
          url: '../index/index?relogin=1',
        })
        return;
      }
      if (res.data.msg != undefined && res.data.msg.length > 0) {
        wx.showModal({
          title: '提示',
          content: res.data.msg,
          showCancel: false,
          confirmText: '确定',
        })
        if (isFunction(callBack.fail)) {
          callBack.fail(res);
        }
      }
      if (isFunction(callBack.success)) {
        callBack.success(res.data.data[0]);
      }
      return;
      x
    }
  })

}




function isFunction(fn) {
  if (fn == undefined) {
    return false;
  }
  return Object.prototype.toString.call(fn) === '[object Function]';
}


module.exports = {
  Post: post,
  Get: get,
  Upload: upload,
  Delete: Delete,
  Put:put,
}