
let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let isLogin;
Page({
  data: {
    imgUrls: [],
    indicatorDots: false,
    autoplay: false,
    interval: 5000,
    duration: 1000,
    showDialog: false,
    isCanWxUseInfo:false,
    billList: [],
  },

  dialogSubmit: function (e) {
    //console.dir(e);
  },

  wxLogin:function(e){
    //console.dir(e);
    this.setData({
      showDialog: false,
    })
    login(this);
  },

  onItemClick:function(e){
    //console.dir(e);
    wx.navigateTo({
      url: '../detailvegatable/index?id=' + e.currentTarget.dataset.item.id,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  onShow: function () {
    refreshHomeData(this)
    isLogin = Data.isLogin();
  },

  onLoad: function () {
    let that = this;
    // util.showToast({ title: '加载中...', duration: 10000 })
    Api.getBanner({ 'page': 0, 'size': 5 },   {
      success:function(e){
        that.setData({
          imgUrls: e.data.content
        });
      }
      // wx.hideToast();
    });

    // if (Data.isLogin() == false) {
    //   // wx.showToast({
    //   //   title: "showToast",
    //   // })
    //   // wx.getSetting({
    //   //   success:res=>{
    //   //     //console.dir(res);
    //   //     if (res.authSetting['scope.userInfo'] ===true){
    //   //       login(that);
    //   //     }else{
    //   //       that.setData({
    //   //         isCanWxUseInfo: false,
    //   //         showDialog: true,
    //   //       })
    //   //     }
    //   //   },
    //   //   fail:res=>{
    //   //     wx.showToast({
    //   //       title: "fail",
    //   //     })
    //   //   }
    //   // })
    //   that.setData({
    //     isCanWxUseInfo: false,
    //     showDialog: true,
    //   })
    // }else{

    // }
  },
  tapPerson() {
    if (Data.isLogin()){
      wx.navigateTo({
        url: '../../me/mycenter/index'
      });
    }else{
      wx.navigateTo({
        url: '../login/login?action=1',
      })
    }

  },
  problemDetail() {
    wx.navigateTo({
      url: '../problem/index'
    });
  },
  tapStory() {
    wx.navigateTo({
      url: '../story/index?id=1'
    });
  },
  tapGiftCard() {
    wx.navigateTo({
      url: '../giftcard/index'
    });
  },
  tapProductIntro() {
    wx.navigateTo({
      url: '../story/index?id=2'
    });
  },
  tapJoinFriend() {
    wx.navigateTo({
      url: '../joinfriend/index'
    });
  },
  tapChoosevegatable() {
    if (Data.isLogin()) {
      wx.navigateTo({
        url: '../chosenvegatable/index'
      });
    } else {
      wx.navigateTo({
        url: '../login/login?action=2',
      })
    }
  },
  tapChoosechicken() {
    wx.navigateTo({
      url: '../chosenchicken/index'
    })
  },
  tapDetail() {
    wx.navigateTo({
      url: '../detailvegatable/index'
    });
  },
  tapNewsarticle() {
    wx.navigateTo({
      url: '../newsarticle/index'
    });
  }
})

function refreshHomeData(that){
  if (Data.isLogin()) {
    Api.getBill({
      'user.id': Data.getUser().id,
      'sort': 'id,desc',
      isShowLoading: false,
    }, {
        success: res => {
          that.setData({
            billList: res.data.content,
          })
        }
      })
  }
}
