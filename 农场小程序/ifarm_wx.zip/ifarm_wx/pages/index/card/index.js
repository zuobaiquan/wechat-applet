// pages/index/card/index.js
Page({
  data: {
    //vegatable or chicken
    type:'vegatable',
    cardInfo:{
      title:'菜地卡',
      dec:'自己种，更放心',
      contenttitle:'我的农场，种出儿时的味道',
      contentdec:'无农药，无化肥，无激素，无保鲜剂'
    }
  },
  onLoad: function (options) {
    if(this.data.type=='chicken'){
      wx.setNavigationBarTitle({
        title:'选鸡卡'
      })
      this.data.cardInfo.title='养鸡卡'
      this.data.cardInfo.dec='自己养，更放心'
      this.data.cardInfo.contenttitle='我的农场，自己养更放心'
      this.data.cardInfo.contentdec='无农药，无化肥，无激素，无保鲜剂'
      this.setData({
        cardInfo:this.data.cardInfo
      })
    }
  },
  onShow: function () {

  }
})
