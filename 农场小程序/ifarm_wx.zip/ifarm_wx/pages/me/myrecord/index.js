// pages/me/myrecord/index.js

let Api = require('../../../api/api.js')
let Data = require('../../../api/data.js')
let Dialog = require('../../../utils/dialog.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    noRecord:false,
    list:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    Api.getOrder({
     'creator.id':Data.getUser().id,
     'sort': "createTime,desc",
    },{
      success:res=>{
        let list = res.data.content;
        for(let i =0 ;i<list.length;i++){
           let item = list[i];
           if(item.payStatus==0){
             item.statusName= '未付款';
           }else if (item.payStatus == 1) {
             item.statusName = '付款中';
           }else if (item.payStatus == 2) {
             item.statusName = '已支付';
           } else if (item.payStatus == 3) {
             item.statusName = '已退款';
           }
          
          let dateName = Data.getDateFromGMT(item.createTime).Format("yyyy-MM-dd hh:mm");  
           item.dateName = dateName;
        }
        this.setData({
          list:list,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})
Date.prototype.Format = function (fmt) { //author: meizz 
  var o = {
    "M+": this.getMonth() + 1, //月份 
    "d+": this.getDate(), //日 
    "h+": this.getHours(), //小时 
    "m+": this.getMinutes(), //分 
    "s+": this.getSeconds(), //秒 
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
    "S": this.getMilliseconds() //毫秒 
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
}
