var debug = true;


var urlDebug = 'https://ifarm.iqiys.cn/test/api/';
var urlRelease = 'https://ifarm.iqiys.cn/api/';
function getBaseUrl() {
  return debug ? urlDebug : urlRelease;
}

module.exports = {
  getBaseUrl: getBaseUrl,
}