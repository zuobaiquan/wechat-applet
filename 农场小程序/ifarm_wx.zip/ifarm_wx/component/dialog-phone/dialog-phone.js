// component/dialog-phone/dialpg-phone.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    bindgetphonenumber:function(e){
      //console.dir(e);
      let data = e.detail;
      if (data.encryptedData!=undefined){
        this.triggerEvent('getPhone', { data: data}, {});
      }
    },
    close: function (e) {
      //console.log(e);
      this.triggerEvent('close', {}, {});
    },
  }
})
